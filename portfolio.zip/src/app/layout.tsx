import type { Metadata } from "next";
import { Inter, Outfit } from "next/font/google";
import "./globals.css";
import LenisProvider from "@/components/LenisProvider";
import ScrollProgressBar from "@/components/ScrollProgressBar";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const outfit = Outfit({
  variable: "--font-outfit",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Yohan Shanuka | ML & Data Engineer · Streaming Data Architecture · Containerized Deployment",
  description: "Portfolio of Yohan Shanuka — specializing in scalable Machine Learning systems, Streaming Data Architecture, Containerized Deployment pipelines, and MLOps.",
  icons: {
    icon: "/icon.png",
    shortcut: "/icon.png",
    apple: "/icon.png",
  },
  openGraph: {
    title: "Yohan Shanuka | ML & Data Engineer · Streaming Data Architecture · Containerized Deployment",
    description: "Building scalable Streaming Data Architectures and Containerized ML Deployment pipelines for production-grade AI systems.",
    url: "https://yohanshanuka.com",
    siteName: "Yohan Shanuka Portfolio",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Yohan Shanuka | ML & Data Engineer · Streaming Data Architecture · Containerized Deployment",
    description: "Building scalable Streaming Data Architectures and Containerized ML Deployment pipelines for production-grade AI systems.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${outfit.variable} antialiased`}
      suppressHydrationWarning
    >
      <body className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col selection:bg-cyan-100 selection:text-cyan-900">
        <ScrollProgressBar />
        <LenisProvider>
          {children}
        </LenisProvider>
      </body>
    </html>
  );
}
